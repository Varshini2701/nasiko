// Self-check for nasiko-shim.js: the traceparent from an inbound A2A request
// must reappear on the LLM leg (that's the whole point — the router 403s
// without it), and A2A method aliasing must still work.
// Run: node test-shim.js
const assert = require('assert');
const http = require('http');
const { spawn } = require('child_process');

const TP = '00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01';
const seen = { llmTraceparent: 'NEVER_CALLED', a2aMethod: null };

function listen(server, port) {
  return new Promise((r) => server.listen(port, '127.0.0.1', r));
}

function post(port, path, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = http.request(
      { host: '127.0.0.1', port, path, method: 'POST',
        headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data), ...headers } },
      (res) => { let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve({ status: res.statusCode, body: d })); },
    );
    req.on('error', reject);
    req.end(data);
  });
}

(async () => {
  // Stand-in for the LLM router: rejects an unattributed call exactly like the real one.
  const router = http.createServer((req, res) => {
    seen.llmTraceparent = req.headers.traceparent || '<none>';
    if (!req.headers.traceparent) {
      res.writeHead(403, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ detail: 'traceparent missing or malformed' }));
      return;
    }
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ id: 'ok', url: req.url }));
  });
  // Stand-in for a2a-opencode.
  const wrapped = http.createServer((req, res) => {
    let b = ''; req.on('data', (c) => (b += c));
    req.on('end', () => {
      seen.a2aMethod = JSON.parse(b).method;
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ jsonrpc: '2.0', id: 1, result: {} }));
    });
  });
  await Promise.all([listen(router, 4599), listen(wrapped, 3599)]);

  const shim = spawn('node', [`${__dirname}/nasiko-shim.js`], {
    env: { ...process.env, SHIM_PORT: '8599', WRAPPED_PORT: '3599',
           LLM_ROUTER_BASE_URL: 'http://127.0.0.1:4599/v1' },
    stdio: 'inherit',
  });
  for (let i = 0; i < 50; i++) {
    try { await post(8599, '/a2a/jsonrpc', { jsonrpc: '2.0', id: 1, method: 'SendMessage' }, { traceparent: TP }); break; }
    catch (_) { await new Promise((r) => setTimeout(r, 100)); }
  }

  // 1. inbound A2A: method aliased, traceparent captured
  await post(8599, '/a2a/jsonrpc', { jsonrpc: '2.0', id: 1, method: 'SendMessage' }, { traceparent: TP });
  assert.strictEqual(seen.a2aMethod, 'message/send');

  // 2. opencode's LLM call carries no traceparent of its own — the shim adds it
  const llm = await post(8599, '/llm/chat/completions', { model: 'gpt-4o', messages: [] });
  assert.strictEqual(seen.llmTraceparent, TP, `router saw traceparent ${seen.llmTraceparent}`);
  assert.strictEqual(llm.status, 200, `router replied ${llm.status}: ${llm.body}`);
  assert.strictEqual(JSON.parse(llm.body).url, '/v1/chat/completions'); // base + path, no /llm

  shim.kill(); router.close(); wrapped.close();
  console.log('ok — traceparent restored on the LLM leg, A2A aliasing intact');
})().catch((e) => { console.error(e); process.exit(1); });
