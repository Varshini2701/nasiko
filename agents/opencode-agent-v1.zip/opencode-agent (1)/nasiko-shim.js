// Nasiko's A2A client sends PascalCase JSON-RPC method names (SendMessage,
// SendStreamingMessage — see oss/types/src/a2a.rs) matching the a2a-lf crate's
// convention. a2a-opencode implements the official A2A spec's slash-form names
// (message/send, message/stream) via @a2a-js/sdk. This shim sits in front of
// a2a-opencode and rewrites the method name so Nasiko's orchestrator can call
// it unmodified. Everything else (streaming, headers, REST, agent card) passes
// through untouched.
//
// It also carries the flow's `traceparent` across to opencode's LLM calls —
// see forwardToRouter below.
const http = require('http');
const { Readable } = require('stream');

const LISTEN_PORT = process.env.SHIM_PORT || 8000;
const TARGET_PORT = process.env.WRAPPED_PORT || 3000;
const TARGET_HOST = '127.0.0.1';
const RPC_PATH = '/a2a/jsonrpc';

// Nasiko's LLM router (oss/llm-router) rejects with 403 every LLM call that
// doesn't carry the W3C `traceparent` of the flow it serves — that header is
// how per-user token attribution and flow budgets work, and there is no
// fallback (oss/llm-router/src/routing/attribution.rs,
// oss/docs/TOKEN_ATTRIBUTION.md). The platform sets it on the inbound A2A
// request (oss/server/src/agent_proxy.rs), and normally OTel
// auto-instrumentation forwards it for free — but here the LLM calls come out
// of a *separate* process (`opencode serve`), uninstrumented, and
// a2a-opencode's prompt API has no way to pass a per-request header down to
// the provider. So: this shim, which already terminates the inbound request
// that carries the header, remembers it and re-attaches it to opencode's
// provider traffic, which entrypoint.sh points at /llm on this same port.
//
// ponytail: one remembered traceparent per container. Two genuinely
// concurrent A2A requests would attribute both users' tokens to whichever
// arrived last; per-request precision needs the flow id threaded through
// opencode itself (upstream change), not reachable from out here.
const LLM_PREFIX = '/llm';
const ROUTER_BASE = (process.env.LLM_ROUTER_BASE_URL || '').replace(/\/+$/, '');
// fetch decodes the body for us; passing these on would make the client
// re-decode plain bytes or mis-frame a stream.
const DROP_RESPONSE_HEADERS = ['content-encoding', 'content-length', 'transfer-encoding'];

let lastTraceparent = null;

const METHOD_ALIASES = {
  SendMessage: 'message/send',
  SendStreamingMessage: 'message/stream',
  GetTask: 'tasks/get',
  CancelTask: 'tasks/cancel',
  ListTasks: 'tasks/list',
};

function forward(req, res, overrideBody) {
  const headers = { ...req.headers };
  if (overrideBody !== undefined) {
    headers['content-length'] = Buffer.byteLength(overrideBody);
  }
  const proxyReq = http.request(
    { hostname: TARGET_HOST, port: TARGET_PORT, path: req.url, method: req.method, headers },
    (proxyRes) => {
      res.writeHead(proxyRes.statusCode, proxyRes.headers);
      proxyRes.pipe(res);
    },
  );
  proxyReq.on('error', (err) => {
    res.writeHead(502);
    res.end(String(err));
  });
  if (overrideBody !== undefined) proxyReq.end(overrideBody);
  else req.pipe(proxyReq);
}

async function forwardToRouter(req, res) {
  if (!ROUTER_BASE) {
    res.writeHead(500);
    res.end('nasiko-shim: LLM_ROUTER_BASE_URL is unset');
    return;
  }
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);

  const headers = { 'content-type': req.headers['content-type'] || 'application/json' };
  if (req.headers.authorization) headers.authorization = req.headers.authorization;
  if (req.headers.accept) headers.accept = req.headers.accept;
  if (lastTraceparent) headers.traceparent = lastTraceparent;

  try {
    const upstream = await fetch(ROUTER_BASE + req.url.slice(LLM_PREFIX.length), {
      method: req.method,
      headers,
      body: chunks.length ? Buffer.concat(chunks) : undefined,
    });
    const out = {};
    for (const [name, value] of upstream.headers) {
      if (!DROP_RESPONSE_HEADERS.includes(name)) out[name] = value;
    }
    if (upstream.status >= 400) {
      console.error(
        `[nasiko-shim] router ${upstream.status} for ${req.url} (traceparent: ${lastTraceparent || '<none seen>'})`,
      );
    }
    res.writeHead(upstream.status, out);
    if (upstream.body) Readable.fromWeb(upstream.body).pipe(res);
    else res.end();
  } catch (err) {
    res.writeHead(502);
    res.end(String(err));
  }
}

http
  .createServer((req, res) => {
    const isLlmLeg = req.url === LLM_PREFIX || req.url.startsWith(`${LLM_PREFIX}/`);
    if (isLlmLeg) {
      forwardToRouter(req, res);
      return;
    }

    // Any inbound platform request carries the current flow's trace context —
    // the A2A call itself, and the tasks/get polls that follow it.
    if (req.headers.traceparent) lastTraceparent = req.headers.traceparent;

    if (req.method === 'POST' && req.url === RPC_PATH) {
      let body = '';
      req.on('data', (c) => (body += c));
      req.on('end', () => {
        let out = body;
        try {
          const parsed = JSON.parse(body);
          if (parsed && METHOD_ALIASES[parsed.method]) {
            parsed.method = METHOD_ALIASES[parsed.method];
            out = JSON.stringify(parsed);
          }
        } catch (_) {
          // not parseable JSON — forward untouched
        }
        forward(req, res, out);
      });
      return;
    }
    forward(req, res);
  })
  .listen(LISTEN_PORT, '0.0.0.0', () => {
    console.log(
      `[nasiko-shim] :${LISTEN_PORT} -> ${TARGET_HOST}:${TARGET_PORT} (aliasing A2A method names), ${LLM_PREFIX}/* -> ${ROUTER_BASE || '<unset>'} (restoring traceparent)`,
    );
  });
